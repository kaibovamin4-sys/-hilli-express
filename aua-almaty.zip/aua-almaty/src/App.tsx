import { useEffect, useMemo, useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import CoverageMap from './components/CoverageMap';
import GapSection from './components/GapSection';
import AdviceSection from './components/AdviceSection';
import AboutSection, { Footer } from './components/AboutSection';
import { DISTRICTS, POSTS, STATION, type District } from './data/demo';
import { idw, statusFor } from './lib/air';

/**
 * Видеофон первого экрана. Замените на свой ролик
 * (например, аэросъёмка Алматы со смогом над городом).
 */
const HERO_VIDEO_URL =
  'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260403_050628_c4e32401-fab4-4a27-b7a8-6e9291cd5959.mp4';

export default function App() {
  const [district, setDistrict] = useState<District>(DISTRICTS[0]);

  const pm = useMemo(() => Math.round(idw(district, [...POSTS, STATION])), [district]);
  const status = statusFor(pm);

  // цвет статуса пробрасывается в CSS-переменную — им красится логотип-точка и акценты
  useEffect(() => {
    document.documentElement.style.setProperty('--status-c', status.cssVar);
  }, [status.cssVar]);

  return (
    <>
      <div className="haze" aria-hidden="true" />
      <div className="grain" aria-hidden="true" />

      <div className="relative z-[1]">
        {/* Видео первого экрана — как в VEX: без оверлея, играет сырым.
            Снизу — только растворение в фон страницы для перехода при скролле. */}
        <div className="absolute top-0 inset-x-0 h-screen overflow-hidden" aria-hidden="true">
          <video
            className="absolute inset-0 h-full w-full object-cover"
            src={HERO_VIDEO_URL}
            autoPlay
            loop
            muted
            playsInline
          />
          <div
            className="absolute inset-x-0 bottom-0 h-40"
            style={{ background: 'linear-gradient(180deg, transparent, var(--bg))' }}
          />
        </div>

        <Navbar statusColor={status.cssVar} />
        <Hero district={district} onDistrictChange={setDistrict} />
        <CoverageMap />
        <GapSection />
        <AdviceSection current={status.key} />
        <AboutSection />
        <Footer />
      </div>
    </>
  );
}
