import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import Section from './Section';
import { DISTRICTS, POSTS, STATION } from '../data/demo';
import { isBlind, nearestPost, pmColor } from '../lib/air';

const LEGEND = [
  { c: 'var(--good)', label: 'чисто · до 35' },
  { c: 'var(--mid)', label: 'средне · 35–75' },
  { c: 'var(--bad)', label: 'плохо · 75+' },
  { c: 'rgba(248,113,113,.25)', label: 'слепая зона', dashed: true },
  { c: '#fff', label: 'наша станция' },
];

export default function CoverageMap() {
  const mapEl = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapEl.current || mapRef.current) return;

    const map = L.map(mapEl.current, { scrollWheelZoom: false }).setView(
      [43.246, 76.9],
      11,
    );
    mapRef.current = map;

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 18,
    }).addTo(map);

    const t = new Date();
    const tstr = `${String(t.getHours()).padStart(2, '0')}:${String(Math.floor(t.getMinutes() / 10) * 10).padStart(2, '0')}`;

    // официальные посты
    for (const p of POSTS) {
      L.circleMarker([p.lat, p.lng], {
        radius: 9,
        color: pmColor(p.pm),
        weight: 2,
        fillColor: pmColor(p.pm),
        fillOpacity: 0.45,
      })
        .addTo(map)
        .bindPopup(
          `<b>${p.name}</b><br>PM2.5: <b>${p.pm} µg/m³</b><br>Последний замер: сегодня, ${tstr}`,
        );
    }

    // наша станция
    L.circleMarker([STATION.lat, STATION.lng], {
      radius: 10,
      color: '#ffffff',
      weight: 2.5,
      fillColor: '#ffffff',
      fillOpacity: 0.9,
    })
      .addTo(map)
      .bindPopup(
        `<b>${STATION.name}</b><br>PM2.5: <b>${STATION.pm} µg/m³</b><br>Последний замер: сегодня, ${tstr}<br><i>в ${(STATION.pm / 30).toFixed(1)} раза выше ближайшего поста</i>`,
      );

    // слепые зоны: сетка точек по городу дальше порога от постов
    for (let la = 43.16; la <= 43.36; la += 0.012) {
      for (let ln = 76.78; ln <= 77.02; ln += 0.016) {
        const p = { lat: la, lng: ln };
        if (isBlind(p, POSTS)) {
          L.circle([p.lat, p.lng], {
            radius: 700,
            color: 'transparent',
            fillColor: '#f87171',
            fillOpacity: 0.06,
            interactive: false,
          }).addTo(map);
        }
      }
    }

    for (const d of DISTRICTS) {
      if (isBlind(d, POSTS)) {
        L.marker([d.lat, d.lng], { opacity: 0 })
          .addTo(map)
          .bindTooltip(
            `${d.name}: слепая зона (до поста ${nearestPost(d, POSTS).d.toFixed(1)} км)`,
          );
      }
    }

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  return (
    <Section
      id="map-sec"
      eyebrow="Экран 2 · Покрытие"
      title="Карта постов и слепые зоны"
      sub="Точки — официальные посты мониторинга. Заштрихованные области — районы, где до ближайшего поста дальше 3,5 км: там официальных измерений фактически нет."
    >
      <div className="liquid-glass rounded-2xl p-2.5">
        <div ref={mapEl} className="h-[480px] rounded-[14px] z-[1]" />
      </div>

      <div className="flex flex-wrap gap-2.5 mt-4">
        {LEGEND.map((l) => (
          <span
            key={l.label}
            className="inline-flex items-center gap-2 text-[13px] text-gray-300 border border-white/15 rounded-full px-3.5 py-1.5 bg-white/[0.03]"
          >
            <span
              className="w-[11px] h-[11px] rounded-full"
              style={{
                background: l.c,
                border: l.dashed ? '1px dashed var(--bad)' : undefined,
              }}
            />
            {l.label}
          </span>
        ))}
      </div>
    </Section>
  );
}
