import { useMemo } from 'react';
import Section from './Section';
import { anomalies, genSeries } from '../lib/air';

const series = genSeries();

export default function GapSection() {
  const anomIdx = useMemo(() => anomalies(series.loc), []);
  const offNow = Math.round(series.off[21]);
  const locNow = Math.round(series.loc[21]);
  const ratio = (locNow / offNow).toFixed(1).replace('.', ',');

  // геометрия графика
  const W = 720;
  const H = 260;
  const P = 24;
  const all = [...series.off, ...series.loc];
  const max = Math.max(...all) * 1.12;
  const x = (i: number) => P + (i / 23) * (W - 2 * P);
  const y = (v: number) => H - P - (v / max) * (H - 2 * P);
  const line = (d: number[]) => d.map((v, i) => `${x(i)},${y(v)}`).join(' ');

  const anomHours = anomIdx.map((i) => `${i}:00`).join(', ');

  return (
    <Section
      id="gap"
      eyebrow="Экран 3 · Главное"
      title={
        <>
          Разрыв: пост показывает одно.
          <br />
          Ваш двор дышит другим.
        </>
      }
      sub="Ближайший официальный пост стоит в стороне от дворов, дорог и частного сектора с печным отоплением. Сравниваем его показания с локальным измерением рядом с вами."
    >
      <div className="grid gap-5 lg:grid-cols-[1fr_1.5fr]">
        {/* сравнение */}
        <div className="liquid-glass rounded-2xl p-7 flex flex-col justify-between gap-5">
          <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3.5">
            <div>
              <div
                className="font-light leading-none"
                style={{ fontSize: 'clamp(44px, 5vw, 72px)', letterSpacing: '-0.04em', color: 'var(--good)' }}
              >
                {offNow}
              </div>
              <div className="text-[13px] text-[color:var(--muted)] mt-2">
                Официальный пост
                <br />
                ПНЗ-16, µg/m³
              </div>
            </div>
            <div className="text-[color:var(--muted)] text-sm">vs</div>
            <div className="text-right">
              <div
                className="font-light leading-none"
                style={{ fontSize: 'clamp(44px, 5vw, 72px)', letterSpacing: '-0.04em', color: 'var(--bad)' }}
              >
                {locNow}
              </div>
              <div className="text-[13px] text-[color:var(--muted)] mt-2">
                Локальное измерение
                <br />у вас, µg/m³
              </div>
            </div>
          </div>

          <div className="h-px" style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.35), transparent)' }} />

          <p className="text-[15px] text-gray-300 leading-relaxed">
            Пост: <b className="text-white font-semibold">{offNow}</b> · У нас:{' '}
            <b className="text-white font-semibold">{locNow}</b> — в{' '}
            <b className="text-white font-semibold">{ratio} раза выше</b>. Для здоровья это
            разница между «спокойно гуляем» и «ребёнку с астмой лучше остаться дома».
            Официальная цифра не ошибается — она просто измерена не там, где вы живёте.
          </p>
        </div>

        {/* график */}
        <div className="liquid-glass rounded-2xl pt-6 px-6 pb-4">
          <div className="flex flex-wrap gap-4 text-[13px] text-gray-300 mb-2">
            <span className="inline-flex items-center gap-2">
              <span className="w-5 h-[2.5px] rounded" style={{ background: 'var(--good)' }} />
              официальный пост
            </span>
            <span className="inline-flex items-center gap-2">
              <span className="w-5 h-[2.5px] rounded" style={{ background: 'var(--bad)' }} />
              локальное измерение
            </span>
            <span className="inline-flex items-center gap-2">
              <span className="w-5 h-2.5 rounded" style={{ background: 'rgba(248,113,113,.3)' }} />
              аномалия (z &gt; 2)
            </span>
          </div>

          <svg
            width="100%"
            height={H}
            viewBox={`0 0 ${W} ${H}`}
            preserveAspectRatio="none"
            aria-label="Официальный пост против локального измерения, 24 часа"
          >
            {[0, 6, 12, 18, 24].map((hh) => {
              const xx = P + (hh / 24) * (W - 2 * P);
              return (
                <g key={hh}>
                  <line x1={xx} y1={P} x2={xx} y2={H - P} stroke="rgba(255,255,255,0.07)" />
                  <text x={xx} y={H - 6} fill="#9aa4b0" fontSize={11} textAnchor="middle" fontFamily="Inter">
                    {hh % 24}:00
                  </text>
                </g>
              );
            })}

            {anomIdx.map((i) => (
              <rect
                key={`a-${i}`}
                x={x(i) - 8}
                y={P}
                width={16}
                height={H - 2 * P}
                fill="rgba(248,113,113,0.10)"
                rx={4}
              />
            ))}

            <polygon
              points={`${x(0)},${H - P} ${line(series.loc)} ${x(23)},${H - P}`}
              fill="rgba(248,113,113,0.07)"
            />
            <polyline points={line(series.off)} fill="none" stroke="var(--good)" strokeWidth={2.5} strokeLinejoin="round" />
            <polyline points={line(series.loc)} fill="none" stroke="var(--bad)" strokeWidth={2.5} strokeLinejoin="round" />

            {anomIdx.map((i) => (
              <circle
                key={`d-${i}`}
                cx={x(i)}
                cy={y(series.loc[i])}
                r={4}
                fill="var(--bad)"
                stroke="#07090c"
                strokeWidth={1.5}
              />
            ))}
          </svg>

          <p className="text-[13px] text-[color:var(--muted)] mt-2">
            {anomIdx.length > 0 ? (
              <>
                Детектор аномалий (z-score &gt; 2σ от скользящего среднего) подсветил резкое
                ухудшение: <b className="text-[color:var(--bad)] font-medium">{anomHours}</b> —
                вечерний пик, совпадает с печным отоплением частного сектора.
              </>
            ) : (
              'Резких аномалий за последние 24 часа не зафиксировано.'
            )}
          </p>
        </div>
      </div>
    </Section>
  );
}
