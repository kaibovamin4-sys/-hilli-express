import type { AirSource, GeoPoint } from '../lib/air';

/**
 * Демо-набор. В проде массив POSTS заполняется fetch-запросами
 * к Kazhydromet / IQAir / air.org.kz — остальная логика не меняется.
 */
export const POSTS: AirSource[] = [
  { id: 'ПНЗ-1', name: 'Пост ПНЗ-1 · центр', lat: 43.2567, lng: 76.9286, pm: 34 },
  { id: 'ПНЗ-16', name: 'Пост ПНЗ-16 · Тастак', lat: 43.2452, lng: 76.8734, pm: 30 },
  { id: 'ПНЗ-25', name: 'Пост ПНЗ-25 · Аксай', lat: 43.2278, lng: 76.8281, pm: 41 },
  { id: 'ПНЗ-28', name: 'Пост ПНЗ-28 · верхняя часть', lat: 43.2129, lng: 76.9553, pm: 22 },
  { id: 'IQ-77', name: 'Датчик IQAir · Медеуский', lat: 43.235, lng: 76.966, pm: 27 },
];

export const STATION: AirSource = {
  id: 'AUA-1',
  name: 'Наша станция · двор в Алатауском р-не',
  lat: 43.2905,
  lng: 76.857,
  pm: 68,
};

export interface District extends GeoPoint {
  name: string;
}

export const DISTRICTS: District[] = [
  { name: 'Алатауский', lat: 43.293, lng: 76.86 },
  { name: 'Алмалинский', lat: 43.25, lng: 76.91 },
  { name: 'Ауэзовский', lat: 43.227, lng: 76.85 },
  { name: 'Бостандыкский', lat: 43.21, lng: 76.92 },
  { name: 'Жетысуский', lat: 43.296, lng: 76.925 },
  { name: 'Медеуский', lat: 43.23, lng: 76.97 },
  { name: 'Наурызбайский', lat: 43.196, lng: 76.82 },
  { name: 'Турксибский', lat: 43.323, lng: 76.945 },
];
