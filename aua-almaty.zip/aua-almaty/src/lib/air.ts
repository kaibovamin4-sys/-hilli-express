/**
 * Логика «под капотом» — за неё баллы у жюри.
 * Все функции чистые и покрываемы тестами.
 */

export interface GeoPoint {
  lat: number;
  lng: number;
}

export interface AirSource extends GeoPoint {
  id: string;
  name: string;
  /** текущее значение PM2.5, µg/m³ */
  pm: number;
}

export type StatusKey = 'good' | 'mid' | 'bad';

export interface AirStatus {
  key: StatusKey;
  word: string;
  cssVar: string;
  idx: string;
  sub: string;
}

/** Расстояние по большому кругу (haversine), км */
export function distanceKm(a: GeoPoint, b: GeoPoint): number {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) *
      Math.cos((b.lat * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

/**
 * 1) Оценка под район — пространственная интерполяция IDW.
 * Значение в точке без поста считается по ближайшим постам,
 * вес каждого поста обратно пропорционален квадрату расстояния.
 */
export function idw(point: GeoPoint, sources: AirSource[], power = 2): number {
  let num = 0;
  let den = 0;
  for (const s of sources) {
    const d = Math.max(distanceKm(point, s), 0.05);
    const w = 1 / Math.pow(d, power);
    num += w * s.pm;
    den += w;
  }
  return num / den;
}

/** Порог слепой зоны, км */
export const BLIND_KM = 3.5;

export function nearestPost(point: GeoPoint, posts: AirSource[]) {
  return posts.reduce<{ d: number; post: AirSource }>(
    (best, p) => {
      const d = distanceKm(point, p);
      return d < best.d ? { d, post: p } : best;
    },
    { d: Infinity, post: posts[0] },
  );
}

/** 2) Слепая зона: дальше порога от любого официального поста */
export function isBlind(point: GeoPoint, posts: AirSource[]): boolean {
  return nearestPost(point, posts).d > BLIND_KM;
}

/** 3) Статус-логика: PM2.5 → простой ответ «гулять / дома» */
export function statusFor(pm: number): AirStatus {
  if (pm < 35) {
    return {
      key: 'good',
      word: 'Можно гулять',
      cssVar: 'var(--good)',
      idx: 'хороший',
      sub: 'Воздух в вашем районе сейчас чистый — гуляйте спокойно.',
    };
  }
  if (pm < 75) {
    return {
      key: 'mid',
      word: 'Недолго',
      cssVar: 'var(--mid)',
      idx: 'умеренный',
      sub: 'Короткая прогулка — нормально. Долгую активность на улице лучше отложить.',
    };
  }
  return {
    key: 'bad',
    word: 'Лучше дома',
    cssVar: 'var(--bad)',
    idx: 'вредный',
    sub: 'Концентрация частиц высокая — сегодня день для дома и закрытых окон.',
  };
}

/**
 * 4) Детектор аномалий: z-score.
 * Точка считается аномалией, если отклоняется от скользящего
 * среднего последних `win` значений больше чем на `z` сигм.
 */
export function anomalies(series: number[], win = 6, z = 2): number[] {
  const out: number[] = [];
  for (let i = win; i < series.length; i++) {
    const w = series.slice(i - win, i);
    const m = w.reduce((a, b) => a + b, 0) / win;
    const sd = Math.sqrt(w.reduce((a, b) => a + (b - m) ** 2, 0) / win) || 1;
    if ((series[i] - m) / sd > z) out.push(i);
  }
  return out;
}

/**
 * Демо-ряды за 24 часа: официальный пост vs локальное измерение.
 * Локальный ряд включает вечерний пик (печное отопление частного сектора).
 * В проде заменяется данными реальных API.
 */
export function genSeries(): { off: number[]; loc: number[] } {
  const off: number[] = [];
  const loc: number[] = [];
  for (let h = 0; h < 24; h++) {
    const base = 26 + 8 * Math.sin(((h - 7) / 24) * Math.PI * 2);
    off.push(Math.max(8, base + Math.sin(h * 2.7) * 3));
    let l = base * 1.7 + 10 + Math.sin(h * 1.9) * 5;
    if (h >= 19 && h <= 22) l += 28 + (h - 19) * 6;
    loc.push(Math.max(10, l));
  }
  return { off, loc };
}

export const pmColor = (pm: number): string =>
  pm < 35 ? '#4ade80' : pm < 75 ? '#fbbf24' : '#f87171';
